﻿public interface IInteractable
{
    public void Interact(Inventory inven);
}