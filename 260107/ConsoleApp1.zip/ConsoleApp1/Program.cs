﻿namespace ConsoleApp1;

class Program
{
    static void Main(string[] args)
    {
        Console.Clear();
        
        GameManager scene = new GameManager();
        scene.Run();
    }
}